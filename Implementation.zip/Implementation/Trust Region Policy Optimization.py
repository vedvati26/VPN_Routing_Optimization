import numpy as np
import os
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras import layers

# VPN Routing Environment (same as before)
class VPNRoutingEnv:
    def __init__(self, data_folder):
        self.vpn_protocols = ["WireGuard", "SSTP", "PPTP", "OpenVPN", "L2TP/IPsec"]
        self.routes = ["route_1", "route_2", "route_3"]
        self.state_size = 4  # Adjust based on available features
        self.action_size = len(self.vpn_protocols) * len(self.routes) + 2  # Select protocol + change route + connect/disconnect

        # Load data from CSV files
        self.data_files = [os.path.join(data_folder, filename) for filename in os.listdir(data_folder) if filename.endswith('.csv')]
        self.current_index = 0
        self.current_data = None

    def load_data(self, file_path):
        return pd.read_csv(file_path)

    def reset(self):
        if not self.data_files:
            raise ValueError("No data files found.")
        self.current_index = random.randint(0, len(self.data_files) - 1)
        self.current_data = self.load_data(self.data_files[self.current_index])
        print(f"Loaded data from: {self.data_files[self.current_index]}")
        print("Columns in current data:", self.current_data.columns.tolist())

        return self.get_state(self.current_data.sample(n=1).iloc[0])

    def step(self, action):
        # Simulate taking an action in the environment and return new state, reward
        latency = random.uniform(20, 150)  # Simulated latency value
        throughput = random.uniform(100, 600)  # Simulated throughput value
        packet_loss = random.uniform(0, 1)  # Simulated packet loss value

        reward = self.calculate_reward(latency, throughput, packet_loss)

        # Move to the next entry in the dataset (circular)
        self.current_index = (self.current_index + 1) % len(self.current_data)

        return self.get_state(self.current_data.iloc[self.current_index]), reward

    def get_state(self, data_entry):
        return np.array([
            data_entry['port_src'],
            data_entry['port_dst'],
            data_entry['x_packets'],
            data_entry['ip_proto']  # You may need to encode this properly
        ])

    def calculate_reward(self, latency, throughput, packet_loss):
        reward = 0
        if latency < 50:
            reward += 10
        elif latency > 100:
            reward -= 10

        if throughput > 500:  # Arbitrary threshold for good throughput
            reward += 5

        if packet_loss > 0:
            reward -= (5 * packet_loss)

        return reward


# Trust Region Policy Optimization (TRPO) Class
class TRPOAgent:
    def __init__(self, env, gamma=0.99, delta=0.01, n_epochs=10, steps_per_epoch=1000):
        self.env = env
        self.gamma = gamma
        self.delta = delta
        self.n_epochs = n_epochs
        self.steps_per_epoch = steps_per_epoch

        # Build the policy network
        self.model = self.build_model()
        self.old_model_weights = self.model.get_weights()

    def build_model(self):
        model = tf.keras.Sequential()
        model.add(layers.Input(shape=(self.env.state_size,)))
        model.add(layers.Dense(64, activation='relu'))
        model.add(layers.Dense(64, activation='relu'))
        model.add(layers.Dense(self.env.action_size, activation='softmax'))  # Action probabilities
        model.compile(optimizer='adam', loss='categorical_crossentropy')
        return model

    def choose_action(self, state):
        state = state.reshape(1, -1)
        probabilities = self.model.predict(state).flatten()
        action = np.random.choice(self.env.action_size, p=probabilities)
        return action

    def compute_advantages(self, rewards, values):
        returns = np.zeros_like(rewards)
        discounted_sum = 0
        for t in reversed(range(len(rewards))):
            discounted_sum = rewards[t] + self.gamma * discounted_sum
            returns[t] = discounted_sum
        advantages = returns - values
        return advantages

    def update_policy(self, states, actions, advantages):
        actions_one_hot = np.eye(self.env.action_size)[actions]
        for _ in range(self.n_epochs):
            # Compute the old policy's log probabilities
            old_probs = self.model.predict(states)
            old_log_probs = np.log(np.sum(old_probs * actions_one_hot, axis=1) + 1e-10)

            with tf.GradientTape() as tape:
                # Compute new probabilities
                new_probs = self.model(states)
                new_log_probs = np.log(np.sum(new_probs * actions_one_hot, axis=1) + 1e-10)
                ratio = tf.exp(new_log_probs - old_log_probs)

                # Surrogate loss
                surrogate = ratio * advantages
                loss = -tf.reduce_mean(tf.minimum(surrogate, tf.clip_by_value(ratio, 1 - self.delta, 1 + self.delta) * advantages))

            grads = tape.gradient(loss, self.model.trainable_variables)
            self.model.optimizer.apply_gradients(zip(grads, self.model.trainable_variables))

        # Update old model weights for the next update
        self.old_model_weights = self.model.get_weights()

    def train(self):
        for episode in range(100):  # Number of episodes
            states, actions, rewards = [], [], []
            state = self.env.reset()
            done = False

            while not done:
                action = self.choose_action(state)
                new_state, reward = self.env.step(action)

                states.append(state)
                actions.append(action)
                rewards.append(reward)

                state = new_state
                done = (len(rewards) >= self.steps_per_epoch)  # Example condition

            # Compute returns and advantages
            values = self.model.predict(np.array(states))  # Get values for states
            advantages = self.compute_advantages(rewards, values)

            # Update policy
            self.update_policy(np.array(states), np.array(actions), advantages)

            print(f"Episode {episode + 1}, Total Reward: {sum(rewards)}")


# Usage Example
data_folder_path = r"D:\Final Capstone\Output"  # Replace with your dataset folder path
env = VPNRoutingEnv(data_folder_path)
trpo_agent = TRPOAgent(env)
trpo_agent.train()
