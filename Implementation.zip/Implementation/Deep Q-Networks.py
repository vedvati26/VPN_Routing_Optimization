import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque
import random
import numpy as np
import os
import pandas as pd
import matplotlib.pyplot as plt

class DQNetwork(nn.Module):
    def __init__(self, input_size, output_size):
        super(DQNetwork, self).__init__()
        self.fc1 = nn.Linear(input_size, 128)
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, output_size)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

class VPNRoutingEnv:
    def __init__(self, data_folder):
        self.vpn_protocols = ["WireGuard", "SSTP", "PPTP", "OpenVPN", "L2TP/IPsec"]
        self.routes = ["route_1", "route_2", "route_3"]
        self.state_size = 4  # Adjust based on available features
        self.action_size = len(self.vpn_protocols) * len(self.routes) + 2  # Select protocol + change route + connect/disconnect

        # Load data from CSV files
        self.data_files = [os.path.join(data_folder, filename) for filename in os.listdir(data_folder) if
                           filename.endswith('.csv')]
        self.current_index = 0
        self.current_data = None

    def load_data(self, file_path):
        return pd.read_csv(file_path)

    def reset(self):
        if not self.data_files:
            raise ValueError("No data files found.")

        self.current_index = random.randint(0, len(self.data_files) - 1)
        self.current_data = self.load_data(self.data_files[self.current_index])
        print(f"Loaded data from: {self.data_files[self.current_index]}")
        print("Columns in current data:", self.current_data.columns.tolist())

        return self.get_state(self.current_data.sample(n=1).iloc[0])

    def step(self, action):
        latency = random.uniform(20, 150)
        throughput = random.uniform(100, 600)
        packet_loss = random.uniform(0, 1)
        reward = self.calculate_reward(latency, throughput, packet_loss)
        self.current_index = (self.current_index + 1) % len(self.current_data)
        return self.get_state(self.current_data.iloc[self.current_index]), reward

    def get_state(self, data_entry):
        return np.array([
            data_entry['port_src'],
            data_entry['port_dst'],
            data_entry['x_packets'],
            data_entry['ip_proto']  # You may need to encode this properly
        ])

    def calculate_reward(self, latency, throughput, packet_loss):
        reward = 0
        if latency < 50:
            reward += 10
        elif latency > 100:
            reward -= 10
        if throughput > 500:
            reward += 5
        if packet_loss > 0:
            reward -= (5 * packet_loss)
        return reward

class VPNRoutingEnvWithDQN(VPNRoutingEnv):
    def __init__(self, data_folder):
        super().__init__(data_folder)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.q_network = DQNetwork(self.state_size, self.action_size).to(self.device)
        self.target_network = DQNetwork(self.state_size, self.action_size).to(self.device)
        self.optimizer = optim.Adam(self.q_network.parameters(), lr=0.001)
        self.memory = deque(maxlen=2000)
        self.gamma = 0.95  # Discount factor
        self.batch_size = 32

    def experience_replay(self):
        if len(self.memory) < self.batch_size:
            return
        batch = random.sample(self.memory, self.batch_size)
        for state, action, reward, next_state in batch:
            q_values = self.q_network(state)
            next_q_values = self.target_network(next_state).detach()
            target = q_values.clone()
            target[action] = reward + self.gamma * next_q_values.max().item()
            loss = torch.nn.functional.mse_loss(q_values, target)
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

    def train_dqn(self, episodes=1000, epsilon=1.0, epsilon_decay=0.995):
        rewards_per_episode = []
        for episode in range(episodes):
            state = torch.FloatTensor(self.reset()).to(self.device)
            total_reward = 0
            for step in range(100):
                if random.uniform(0, 1) < epsilon:
                    action = random.randint(0, self.action_size - 1)  # Explore
                else:
                    with torch.no_grad():
                        action = torch.argmax(self.q_network(state)).item()  # Exploit
                new_state, reward = self.step(action)
                new_state = torch.FloatTensor(new_state).to(self.device)
                self.memory.append((state, action, reward, new_state))
                total_reward += reward
                state = new_state
                self.experience_replay()
            epsilon *= epsilon_decay
            rewards_per_episode.append(total_reward)
            print(f"Episode {episode}: Total Reward: {total_reward}")

        self.target_network.load_state_dict(self.q_network.state_dict())
        plot_results(rewards_per_episode)

def plot_results(rewards_per_episode):
    plt.figure(figsize=(10, 5))
    plt.plot(rewards_per_episode)
    plt.title('Rewards per Episode')
    plt.xlabel('Episode')
    plt.ylabel('Total Reward')
    plt.show()

# Usage Example
data_folder_path = r"D:\Final Capstone\Output"  # Path to your CSV files
env = VPNRoutingEnvWithDQN(data_folder_path)
env.train_dqn(episodes=1000)
