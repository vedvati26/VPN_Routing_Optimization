import numpy as np
import random
import os
import pandas as pd
import matplotlib.pyplot as plt
import math

# VPN Routing Environment (same as before)
class VPNRoutingEnv:
    def __init__(self, data_folder):
        self.vpn_protocols = ["WireGuard", "SSTP", "PPTP", "OpenVPN", "L2TP/IPsec"]
        self.routes = ["route_1", "route_2", "route_3"]
        self.state_size = 4  # Adjust based on available features
        self.action_size = len(self.vpn_protocols) * len(self.routes) + 2  # Select protocol + change route + connect/disconnect

        # Load data from CSV files
        self.data_files = [os.path.join(data_folder, filename) for filename in os.listdir(data_folder) if filename.endswith('.csv')]
        self.current_index = 0
        self.current_data = None

    def load_data(self, file_path):
        return pd.read_csv(file_path)

    def reset(self):
        if not self.data_files:
            raise ValueError("No data files found.")
        self.current_index = random.randint(0, len(self.data_files) - 1)
        self.current_data = self.load_data(self.data_files[self.current_index])
        print(f"Loaded data from: {self.data_files[self.current_index]}")
        print("Columns in current data:", self.current_data.columns.tolist())

        return self.get_state(self.current_data.sample(n=1).iloc[0])

    def step(self, action):
        # Simulate taking an action in the environment and return new state, reward
        latency = random.uniform(20, 150)  # Simulated latency value
        throughput = random.uniform(100, 600)  # Simulated throughput value
        packet_loss = random.uniform(0, 1)  # Simulated packet loss value

        reward = self.calculate_reward(latency, throughput, packet_loss)

        # Move to the next entry in the dataset (circular)
        self.current_index = (self.current_index + 1) % len(self.current_data)

        return self.get_state(self.current_data.iloc[self.current_index]), reward

    def get_state(self, data_entry):
        return np.array([
            data_entry['port_src'],
            data_entry['port_dst'],
            data_entry['x_packets'],
            data_entry['ip_proto']  # You may need to encode this properly
        ])

    def calculate_reward(self, latency, throughput, packet_loss):
        reward = 0
        if latency < 50:
            reward += 10
        elif latency > 100:
            reward -= 10

        if throughput > 500:  # Arbitrary threshold for good throughput
            reward += 5

        if packet_loss > 0:
            reward -= (5 * packet_loss)

        return reward

# Simulated Annealing Class
class SimulatedAnnealingVPNRouting:
    def __init__(self, env, initial_temp=1000, cooling_rate=0.003, max_steps=1000):
        self.env = env
        self.initial_temp = initial_temp
        self.cooling_rate = cooling_rate
        self.max_steps = max_steps
        self.action_size = env.action_size

    def initial_solution(self):
        # Generate a random initial solution (sequence of actions)
        return np.random.randint(0, self.action_size, size=100)

    def fitness_function(self, solution):
        # The fitness is the total reward the solution achieves in the environment
        total_reward = 0
        state = self.env.reset()
        for action in solution:
            new_state, reward = self.env.step(action)
            total_reward += reward
            state = new_state
        return total_reward

    def neighbor_solution(self, current_solution):
        # Modify a single action in the current solution to generate a neighboring solution
        neighbor = current_solution.copy()
        index = random.randint(0, len(neighbor) - 1)
        neighbor[index] = random.randint(0, self.action_size - 1)
        return neighbor

    def probability(self, delta, temperature):
        # Calculate the probability of accepting a worse solution
        return math.exp(-delta / temperature)

    def run(self):
        # Initialize the current solution and temperature
        current_solution = self.initial_solution()
        current_fitness = self.fitness_function(current_solution)
        temperature = self.initial_temp

        fitness_history = [current_fitness]

        for step in range(self.max_steps):
            if temperature > 1:
                # Generate a neighboring solution
                neighbor_solution = self.neighbor_solution(current_solution)
                neighbor_fitness = self.fitness_function(neighbor_solution)

                # Check if the new solution is better
                if neighbor_fitness > current_fitness:
                    current_solution = neighbor_solution
                    current_fitness = neighbor_fitness
                else:
                    # Accept worse solutions with a probability based on the current temperature
                    delta = current_fitness - neighbor_fitness
                    if random.uniform(0, 1) < self.probability(delta, temperature):
                        current_solution = neighbor_solution
                        current_fitness = neighbor_fitness

                # Cool down the system
                temperature *= (1 - self.cooling_rate)

                fitness_history.append(current_fitness)

                print(f"Step {step + 1}, Fitness: {current_fitness}, Temperature: {temperature}")

            else:
                break

        # Plot results
        self.plot_fitness(fitness_history)

    def plot_fitness(self, fitness_history):
        plt.plot(fitness_history)
        plt.title('Fitness over Steps (Simulated Annealing)')
        plt.xlabel('Steps')
        plt.ylabel('Fitness')
        plt.show()

# Usage Example
data_folder_path = r"D:\Final Capstone\Output"  # Replace with your dataset folder path
env = VPNRoutingEnv(data_folder_path)
sa = SimulatedAnnealingVPNRouting(env)
sa.run()
