import numpy as np
import random
import os
import pandas as pd
import matplotlib.pyplot as plt

# VPN Routing Environment (same as before)
class VPNRoutingEnv:
    def __init__(self, data_folder):
        self.vpn_protocols = ["WireGuard", "SSTP", "PPTP", "OpenVPN", "L2TP/IPsec"]
        self.routes = ["route_1", "route_2", "route_3"]
        self.state_size = 4  # Adjust based on available features
        self.action_size = len(self.vpn_protocols) * len(self.routes) + 2  # Select protocol + change route + connect/disconnect

        # Load data from CSV files
        self.data_files = [os.path.join(data_folder, filename) for filename in os.listdir(data_folder) if filename.endswith('.csv')]
        self.current_index = 0
        self.current_data = None

    def load_data(self, file_path):
        return pd.read_csv(file_path)

    def reset(self):
        if not self.data_files:
            raise ValueError("No data files found.")
        self.current_index = random.randint(0, len(self.data_files) - 1)
        self.current_data = self.load_data(self.data_files[self.current_index])
        print(f"Loaded data from: {self.data_files[self.current_index]}")
        print("Columns in current data:", self.current_data.columns.tolist())

        return self.get_state(self.current_data.sample(n=1).iloc[0])

    def step(self, action):
        # Simulate taking an action in the environment and return new state, reward
        latency = random.uniform(20, 150)  # Simulated latency value
        throughput = random.uniform(100, 600)  # Simulated throughput value
        packet_loss = random.uniform(0, 1)  # Simulated packet loss value

        reward = self.calculate_reward(latency, throughput, packet_loss)

        # Move to the next entry in the dataset (circular)
        self.current_index = (self.current_index + 1) % len(self.current_data)

        return self.get_state(self.current_data.iloc[self.current_index]), reward

    def get_state(self, data_entry):
        return np.array([
            data_entry['port_src'],
            data_entry['port_dst'],
            data_entry['x_packets'],
            data_entry['ip_proto']  # You may need to encode this properly
        ])

    def calculate_reward(self, latency, throughput, packet_loss):
        reward = 0
        if latency < 50:
            reward += 10
        elif latency > 100:
            reward -= 10

        if throughput > 500:  # Arbitrary threshold for good throughput
            reward += 5

        if packet_loss > 0:
            reward -= (5 * packet_loss)

        return reward


# Evolution Strategies Class
class EvolutionStrategiesVPNRouting:
    def __init__(self, env, population_size=50, mutation_strength=0.1, generations=1000):
        self.env = env
        self.population_size = population_size
        self.mutation_strength = mutation_strength
        self.generations = generations
        self.action_size = env.action_size

    def initial_population(self):
        # Generate an initial population of random solutions (sequence of actions)
        return [np.random.randint(0, self.action_size, size=100) for _ in range(self.population_size)]

    def fitness_function(self, solution):
        # The fitness is the total reward the solution achieves in the environment
        total_reward = 0
        state = self.env.reset()
        for action in solution:
            new_state, reward = self.env.step(action)
            total_reward += reward
            state = new_state
        return total_reward

    def mutate(self, solution):
        # Mutate the solution by randomly altering some actions
        new_solution = solution.copy()
        for i in range(len(new_solution)):
            if random.uniform(0, 1) < self.mutation_strength:
                new_solution[i] = random.randint(0, self.action_size - 1)
        return new_solution

    def recombine(self, parent1, parent2):
        # Recombine two parents to create an offspring
        child = np.copy(parent1)
        crossover_point = random.randint(0, len(parent1) - 1)
        child[crossover_point:] = parent2[crossover_point:]
        return child

    def run(self):
        # Initialize population
        population = self.initial_population()
        fitness_history = []

        for generation in range(self.generations):
            # Evaluate fitness of the population
            fitness_scores = [self.fitness_function(solution) for solution in population]
            best_fitness = max(fitness_scores)
            fitness_history.append(best_fitness)

            print(f"Generation {generation + 1}, Best Fitness: {best_fitness}")

            # Select the top individuals (elitism)
            top_indices = np.argsort(fitness_scores)[-int(self.population_size / 2):]
            top_individuals = [population[i] for i in top_indices]

            # Generate new population through mutation and recombination
            new_population = []
            for _ in range(self.population_size):
                parent1 = random.choice(top_individuals)
                parent2 = random.choice(top_individuals)
                child = self.recombine(parent1, parent2)
                mutated_child = self.mutate(child)
                new_population.append(mutated_child)

            population = new_population

        # Plot the fitness progress
        self.plot_fitness(fitness_history)

    def plot_fitness(self, fitness_history):
        plt.plot(fitness_history)
        plt.title('Fitness over Generations (Evolution Strategies)')
        plt.xlabel('Generations')
        plt.ylabel('Fitness')
        plt.show()


# Usage Example
data_folder_path = r"D:\Final Capstone\Output"  # Replace with your dataset folder path
env = VPNRoutingEnv(data_folder_path)
es = EvolutionStrategiesVPNRouting(env)
es.run()
