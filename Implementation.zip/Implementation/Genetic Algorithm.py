import numpy as np
import random
import os
import pandas as pd
import matplotlib.pyplot as plt

# Multi-Agent VPN Routing Environment
class VPNRoutingEnv:
    def __init__(self, data_folder):
        self.vpn_protocols = ["WireGuard", "SSTP", "PPTP", "OpenVPN", "L2TP/IPsec"]
        self.routes = ["route_1", "route_2", "route_3"]
        self.state_size = 4  # Adjust based on available features
        self.action_size = len(self.vpn_protocols) * len(self.routes) + 2  # Select protocol + change route + connect/disconnect

        # Load data from CSV files
        self.data_files = [os.path.join(data_folder, filename) for filename in os.listdir(data_folder) if filename.endswith('.csv')]
        self.current_index = 0
        self.current_data = None

    def load_data(self, file_path):
        return pd.read_csv(file_path)

    def reset(self):
        if not self.data_files:
            raise ValueError("No data files found.")
        self.current_index = random.randint(0, len(self.data_files) - 1)
        self.current_data = self.load_data(self.data_files[self.current_index])
        print(f"Loaded data from: {self.data_files[self.current_index]}")
        print("Columns in current data:", self.current_data.columns.tolist())

        return self.get_state(self.current_data.sample(n=1).iloc[0])

    def step(self, action):
        # Simulate taking an action in the environment and return new state, reward
        latency = random.uniform(20, 150)  # Simulated latency value
        throughput = random.uniform(100, 600)  # Simulated throughput value
        packet_loss = random.uniform(0, 1)  # Simulated packet loss value

        reward = self.calculate_reward(latency, throughput, packet_loss)

        # Move to the next entry in the dataset (circular)
        self.current_index = (self.current_index + 1) % len(self.current_data)

        return self.get_state(self.current_data.iloc[self.current_index]), reward

    def get_state(self, data_entry):
        return np.array([
            data_entry['port_src'],
            data_entry['port_dst'],
            data_entry['x_packets'],
            data_entry['ip_proto']  # You may need to encode this properly
        ])

    def calculate_reward(self, latency, throughput, packet_loss):
        reward = 0
        if latency < 50:
            reward += 10
        elif latency > 100:
            reward -= 10

        if throughput > 500:  # Arbitrary threshold for good throughput
            reward += 5

        if packet_loss > 0:
            reward -= (5 * packet_loss)

        return reward

# Genetic Algorithm Class
class GeneticAlgorithmVPNRouting:
    def __init__(self, env, population_size=50, mutation_rate=0.1, generations=100):
        self.env = env
        self.population_size = population_size
        self.mutation_rate = mutation_rate
        self.generations = generations
        self.action_size = env.action_size

    def initialize_population(self):
        # Each individual in the population is a vector of actions
        return [np.random.randint(0, self.action_size, size=100) for _ in range(self.population_size)]

    def fitness_function(self, individual):
        # The fitness is the total reward the individual achieves in the environment
        total_reward = 0
        state = self.env.reset()
        for action in individual:
            new_state, reward = self.env.step(action)
            total_reward += reward
            state = new_state
        return total_reward

    def selection(self, population, fitness_scores):
        # Select individuals based on their fitness scores (roulette-wheel selection)
        fitness_sum = sum(fitness_scores)
        probabilities = [fitness / fitness_sum for fitness in fitness_scores]
        selected_indices = np.random.choice(len(population), size=len(population), p=probabilities)
        return [population[i] for i in selected_indices]

    def crossover(self, parent1, parent2):
        # Single-point crossover
        crossover_point = random.randint(0, len(parent1) - 1)
        child1 = np.concatenate((parent1[:crossover_point], parent2[crossover_point:]))
        child2 = np.concatenate((parent2[:crossover_point], parent1[crossover_point:]))
        return child1, child2

    def mutate(self, individual):
        # Random mutation
        for i in range(len(individual)):
            if random.uniform(0, 1) < self.mutation_rate:
                individual[i] = random.randint(0, self.action_size - 1)
        return individual

    def evolve(self, population):
        # Compute fitness for the entire population
        fitness_scores = [self.fitness_function(individual) for individual in population]

        # Select individuals based on their fitness
        new_population = self.selection(population, fitness_scores)

        # Apply crossover and mutation to generate the next population
        next_population = []
        for i in range(0, len(new_population), 2):
            parent1 = new_population[i]
            parent2 = new_population[i + 1] if i + 1 < len(new_population) else new_population[0]
            child1, child2 = self.crossover(parent1, parent2)
            next_population.append(self.mutate(child1))
            next_population.append(self.mutate(child2))

        return next_population, max(fitness_scores)

    def run(self):
        population = self.initialize_population()
        fitness_history = []

        for generation in range(self.generations):
            population, max_fitness = self.evolve(population)
            fitness_history.append(max_fitness)
            print(f"Generation {generation + 1}, Max Fitness: {max_fitness}")

        # Plot results
        self.plot_fitness(fitness_history)

    def plot_fitness(self, fitness_history):
        plt.plot(fitness_history)
        plt.title('Fitness over Generations')
        plt.xlabel('Generation')
        plt.ylabel('Max Fitness')
        plt.show()

# Usage Example
data_folder_path = r"D:\Final Capstone\Output"  # Replace with your dataset folder path
env = VPNRoutingEnv(data_folder_path)
ga = GeneticAlgorithmVPNRouting(env)
ga.run()
