import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random
import os
import pandas as pd
import matplotlib.pyplot as plt
from collections import deque

# Define the Q-Network
class DQNetwork(nn.Module):
    def __init__(self, input_size, output_size):
        super(DQNetwork, self).__init__()
        self.fc1 = nn.Linear(input_size, 128)
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, output_size)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

# Multi-Agent VPN Routing Environment
class VPNRoutingEnv:
    def __init__(self, data_folder, num_agents=3):
        self.vpn_protocols = ["WireGuard", "SSTP", "PPTP", "OpenVPN", "L2TP/IPsec"]
        self.routes = ["route_1", "route_2", "route_3"]
        self.state_size = 4  # Adjust based on available features
        self.action_size = len(self.vpn_protocols) * len(self.routes) + 2  # Select protocol + change route + connect/disconnect
        self.num_agents = num_agents  # Multi-agent setup

        # Load data from CSV files
        self.data_files = [os.path.join(data_folder, filename) for filename in os.listdir(data_folder) if filename.endswith('.csv')]
        self.current_index = 0
        self.current_data = None

    def load_data(self, file_path):
        return pd.read_csv(file_path)

    def reset(self):
        if not self.data_files:
            raise ValueError("No data files found.")
        self.current_index = random.randint(0, len(self.data_files) - 1)
        self.current_data = self.load_data(self.data_files[self.current_index])
        print(f"Loaded data from: {self.data_files[self.current_index]}")
        print("Columns in current data:", self.current_data.columns.tolist())

        # Each agent gets a different row (state)
        states = [self.get_state(self.current_data.sample(n=1).iloc[0]) for _ in range(self.num_agents)]
        return states

    def step(self, actions):
        # For multi-agent, actions is a list of actions for each agent
        rewards = []
        next_states = []
        for action in actions:
            latency = random.uniform(20, 150)
            throughput = random.uniform(100, 600)
            packet_loss = random.uniform(0, 1)
            reward = self.calculate_reward(latency, throughput, packet_loss)
            rewards.append(reward)

            self.current_index = (self.current_index + 1) % len(self.current_data)
            next_states.append(self.get_state(self.current_data.iloc[self.current_index]))

        # Global reward for cooperation (sum of individual rewards)
        global_reward = sum(rewards) / len(rewards)  # Average global reward
        return next_states, global_reward

    def get_state(self, data_entry):
        return np.array([
            data_entry['port_src'],
            data_entry['port_dst'],
            data_entry['x_packets'],
            data_entry['ip_proto']  # You may need to encode this properly
        ])

    def calculate_reward(self, latency, throughput, packet_loss):
        reward = 0
        if latency < 50:
            reward += 10
        elif latency > 100:
            reward -= 10
        if throughput > 500:
            reward += 5
        if packet_loss > 0:
            reward -= (5 * packet_loss)
        return reward

class MultiAgentVPNRoutingEnvWithDQN(VPNRoutingEnv):
    def __init__(self, data_folder, num_agents=3):
        super().__init__(data_folder, num_agents)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # Each agent gets its own Q-network
        self.q_networks = [DQNetwork(self.state_size, self.action_size).to(self.device) for _ in range(self.num_agents)]
        self.target_networks = [DQNetwork(self.state_size, self.action_size).to(self.device) for _ in range(self.num_agents)]

        self.optimizers = [optim.Adam(q_network.parameters(), lr=0.001) for q_network in self.q_networks]
        self.memory = deque(maxlen=2000)
        self.gamma = 0.95  # Discount factor
        self.batch_size = 32

    def experience_replay(self):
        if len(self.memory) < self.batch_size:
            return
        batch = random.sample(self.memory, self.batch_size)

        for i in range(self.num_agents):
            for state, action, reward, next_state in batch:
                q_values = self.q_networks[i](state[i])
                next_q_values = self.target_networks[i](next_state[i]).detach()
                target = q_values.clone()
                target[action[i]] = reward + self.gamma * next_q_values.max().item()

                loss = torch.nn.functional.mse_loss(q_values, target)
                self.optimizers[i].zero_grad()
                loss.backward()
                self.optimizers[i].step()

    def train_multi_agent_dqn(self, episodes=1000, epsilon=1.0, epsilon_decay=0.995):
        rewards_per_episode = []
        for episode in range(episodes):
            states = [torch.FloatTensor(state).to(self.device) for state in self.reset()]
            total_reward = 0
            for step in range(100):
                actions = []
                for i in range(self.num_agents):
                    if random.uniform(0, 1) < epsilon:
                        action = random.randint(0, self.action_size - 1)  # Explore
                    else:
                        with torch.no_grad():
                            action = torch.argmax(self.q_networks[i](states[i])).item()  # Exploit
                    actions.append(action)

                new_states, reward = self.step(actions)
                new_states = [torch.FloatTensor(state).to(self.device) for state in new_states]

                self.memory.append((states, actions, reward, new_states))

                total_reward += reward
                states = new_states
                self.experience_replay()

            epsilon *= epsilon_decay
            rewards_per_episode.append(total_reward)
            print(f"Episode {episode}: Total Reward: {total_reward}")

            # Update target networks
            for i in range(self.num_agents):
                self.target_networks[i].load_state_dict(self.q_networks[i].state_dict())

        plot_results(rewards_per_episode)

def plot_results(rewards_per_episode):
    plt.figure(figsize=(10, 5))
    plt.plot(rewards_per_episode)
    plt.title('Rewards per Episode')
    plt.xlabel('Episode')
    plt.ylabel('Total Reward')
    plt.show()

# Usage Example
data_folder_path = r"D:\Final Capstone\Output"  # Path to your CSV files
env = MultiAgentVPNRoutingEnvWithDQN(data_folder_path, num_agents=3)
env.train_multi_agent_dqn(episodes=1000)
