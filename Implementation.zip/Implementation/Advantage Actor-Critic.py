import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import random
import os
import pandas as pd
import matplotlib.pyplot as plt

# Actor Network
class Actor(nn.Module):
    def __init__(self, input_size, output_size):
        super(Actor, self).__init__()
        self.fc1 = nn.Linear(input_size, 128)
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, output_size)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return self.softmax(x)

# Critic Network
class Critic(nn.Module):
    def __init__(self, input_size):
        super(Critic, self).__init__()
        self.fc1 = nn.Linear(input_size, 128)
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, 1)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

class VPNRoutingEnv:
    def __init__(self, data_folder):
        self.vpn_protocols = ["WireGuard", "SSTP", "PPTP", "OpenVPN", "L2TP/IPsec"]
        self.routes = ["route_1", "route_2", "route_3"]
        self.state_size = 4  # Adjust based on available features
        self.action_size = len(self.vpn_protocols) * len(self.routes) + 2  # Select protocol + change route + connect/disconnect

        # Load data from CSV files
        self.data_files = [os.path.join(data_folder, filename) for filename in os.listdir(data_folder) if
                           filename.endswith('.csv')]
        self.current_index = 0
        self.current_data = None

    def load_data(self, file_path):
        return pd.read_csv(file_path)

    def reset(self):
        if not self.data_files:
            raise ValueError("No data files found.")

        self.current_index = random.randint(0, len(self.data_files) - 1)
        self.current_data = self.load_data(self.data_files[self.current_index])
        print(f"Loaded data from: {self.data_files[self.current_index]}")
        print("Columns in current data:", self.current_data.columns.tolist())

        return self.get_state(self.current_data.sample(n=1).iloc[0])

    def step(self, action):
        latency = random.uniform(20, 150)
        throughput = random.uniform(100, 600)
        packet_loss = random.uniform(0, 1)
        reward = self.calculate_reward(latency, throughput, packet_loss)
        self.current_index = (self.current_index + 1) % len(self.current_data)
        return self.get_state(self.current_data.iloc[self.current_index]), reward

    def get_state(self, data_entry):
        return np.array([
            data_entry['port_src'],
            data_entry['port_dst'],
            data_entry['x_packets'],
            data_entry['ip_proto']  # You may need to encode this properly
        ])

    def calculate_reward(self, latency, throughput, packet_loss):
        reward = 0
        if latency < 50:
            reward += 10
        elif latency > 100:
            reward -= 10
        if throughput > 500:
            reward += 5
        if packet_loss > 0:
            reward -= (5 * packet_loss)
        return reward

class VPNRoutingEnvWithA2C(VPNRoutingEnv):
    def __init__(self, data_folder):
        super().__init__(data_folder)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.actor = Actor(self.state_size, self.action_size).to(self.device)
        self.critic = Critic(self.state_size).to(self.device)
        self.optimizer_actor = optim.Adam(self.actor.parameters(), lr=0.001)
        self.optimizer_critic = optim.Adam(self.critic.parameters(), lr=0.001)
        self.gamma = 0.99  # Discount factor

    def train_a2c(self, episodes=1000, epsilon=1.0, epsilon_decay=0.995):
        rewards_per_episode = []
        for episode in range(episodes):
            state = torch.FloatTensor(self.reset()).to(self.device)
            total_reward = 0
            for step in range(100):
                # Select action using actor network
                probs = self.actor(state)
                action_dist = torch.distributions.Categorical(probs)
                action = action_dist.sample().item()

                new_state, reward = self.step(action)
                new_state = torch.FloatTensor(new_state).to(self.device)

                # Compute value of current and next state using critic
                value = self.critic(state)
                next_value = self.critic(new_state).detach()

                # Compute advantage
                advantage = reward + self.gamma * next_value - value

                # Update actor (policy gradient)
                log_prob = action_dist.log_prob(torch.tensor(action).to(self.device))
                actor_loss = -log_prob * advantage.item()

                # Update critic (value function)
                critic_loss = advantage.pow(2)

                # Perform backprop
                self.optimizer_actor.zero_grad()
                actor_loss.backward()
                self.optimizer_actor.step()

                self.optimizer_critic.zero_grad()
                critic_loss.backward()
                self.optimizer_critic.step()

                total_reward += reward
                state = new_state

            rewards_per_episode.append(total_reward)
            print(f"Episode {episode}: Total Reward: {total_reward}")

        plot_results(rewards_per_episode)

def plot_results(rewards_per_episode):
    plt.figure(figsize=(10, 5))
    plt.plot(rewards_per_episode)
    plt.title('Rewards per Episode')
    plt.xlabel('Episode')
    plt.ylabel('Total Reward')
    plt.show()

# Usage Example
data_folder_path = r"D:\Final Capstone\Output"  # Path to your CSV files
env = VPNRoutingEnvWithA2C(data_folder_path)
env.train_a2c(episodes=1000)
