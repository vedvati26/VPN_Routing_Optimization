import numpy as np
import os
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras import layers
import random

# VPN Routing Environment (same as before)
class VPNRoutingEnv:
    def __init__(self, data_folder):
        self.vpn_protocols = ["WireGuard", "SSTP", "PPTP", "OpenVPN", "L2TP/IPsec"]
        self.routes = ["route_1", "route_2", "route_3"]
        self.state_size = 4  # Adjust based on available features
        self.action_size = len(self.vpn_protocols) * len(self.routes) + 2  # Select protocol + change route + connect/disconnect

        # Load data from CSV files
        self.data_files = [os.path.join(data_folder, filename) for filename in os.listdir(data_folder) if filename.endswith('.csv')]
        self.current_index = 0
        self.current_data = None

    def load_data(self, file_path):
        return pd.read_csv(file_path)

    def reset(self):
        if not self.data_files:
            raise ValueError("No data files found.")
        self.current_index = random.randint(0, len(self.data_files) - 1)
        self.current_data = self.load_data(self.data_files[self.current_index])
        print(f"Loaded data from: {self.data_files[self.current_index]}")
        print("Columns in current data:", self.current_data.columns.tolist())

        return self.get_state(self.current_data.sample(n=1).iloc[0])

    def step(self, action):
        # Simulate taking an action in the environment and return new state, reward
        latency = random.uniform(20, 150)  # Simulated latency value
        throughput = random.uniform(100, 600)  # Simulated throughput value
        packet_loss = random.uniform(0, 1)  # Simulated packet loss value

        reward = self.calculate_reward(latency, throughput, packet_loss)

        # Move to the next entry in the dataset (circular)
        self.current_index = (self.current_index + 1) % len(self.current_data)

        return self.get_state(self.current_data.iloc[self.current_index]), reward

    def get_state(self, data_entry):
        return np.array([
            data_entry['port_src'],
            data_entry['port_dst'],
            data_entry['x_packets'],
            data_entry['ip_proto']  # You may need to encode this properly
        ])

    def calculate_reward(self, latency, throughput, packet_loss):
        reward = 0
        if latency < 50:
            reward += 10
        elif latency > 100:
            reward -= 10

        if throughput > 500:  # Arbitrary threshold for good throughput
            reward += 5

        if packet_loss > 0:
            reward -= (5 * packet_loss)

        return reward


# Q-Learning with Function Approximation Class
class QLearningFAAgent:
    def __init__(self, env, alpha=0.001, gamma=0.99, epsilon=1.0, epsilon_decay=0.995, epsilon_min=0.01):
        self.env = env
        self.alpha = alpha  # Learning rate
        self.gamma = gamma  # Discount factor
        self.epsilon = epsilon  # Exploration rate
        self.epsilon_decay = epsilon_decay
        self.epsilon_min = epsilon_min

        # Build the Q-value network
        self.model = self.build_model()

    def build_model(self):
        model = tf.keras.Sequential()
        model.add(layers.Input(shape=(self.env.state_size,)))
        model.add(layers.Dense(64, activation='relu'))
        model.add(layers.Dense(64, activation='relu'))
        model.add(layers.Dense(self.env.action_size, activation='linear'))  # Q-values for each action
        model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=self.alpha), loss='mse')
        return model

    def choose_action(self, state):
        if np.random.rand() < self.epsilon:
            return np.random.randint(self.env.action_size)  # Explore
        else:
            q_values = self.model.predict(state.reshape(1, -1))
            return np.argmax(q_values[0])  # Exploit

    def train(self, episodes=1000):
        rewards_per_episode = []

        for episode in range(episodes):
            state = self.env.reset()
            done = False
            total_reward = 0

            while not done:
                action = self.choose_action(state)
                new_state, reward = self.env.step(action)

                total_reward += reward

                # Update the Q-value for the action taken
                target = reward + self.gamma * np.max(self.model.predict(new_state.reshape(1, -1)))
                target_f = self.model.predict(state.reshape(1, -1))
                target_f[0][action] = target

                # Fit the model
                self.model.fit(state.reshape(1, -1), target_f, epochs=1, verbose=0)

                state = new_state
                done = (len(rewards_per_episode) >= 100)  # Example condition

            self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)
            rewards_per_episode.append(total_reward)

            print(f"Episode {episode + 1}, Total Reward: {total_reward}, Epsilon: {self.epsilon:.3f}")

        return rewards_per_episode


# Usage Example
data_folder_path = r"D:\Final Capstone\Output"  # Replace with your dataset folder path
env = VPNRoutingEnv(data_folder_path)
q_learning_agent = QLearningFAAgent(env)
rewards = q_learning_agent.train(episodes=1000)

# Plotting results
plt.plot(rewards)
plt.title('Total Reward per Episode')
plt.xlabel('Episode')
plt.ylabel('Total Reward')
plt.show()
