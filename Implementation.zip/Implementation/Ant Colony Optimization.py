import numpy as np
import random
import os
import pandas as pd
import matplotlib.pyplot as plt

# VPN Routing Environment (same as before)
class VPNRoutingEnv:
    def __init__(self, data_folder):
        self.vpn_protocols = ["WireGuard", "SSTP", "PPTP", "OpenVPN", "L2TP/IPsec"]
        self.routes = ["route_1", "route_2", "route_3"]
        self.state_size = 4  # Adjust based on available features
        self.action_size = len(self.vpn_protocols) * len(self.routes) + 2  # Select protocol + change route + connect/disconnect

        # Load data from CSV files
        self.data_files = [os.path.join(data_folder, filename) for filename in os.listdir(data_folder) if filename.endswith('.csv')]
        self.current_index = 0
        self.current_data = None

    def load_data(self, file_path):
        return pd.read_csv(file_path)

    def reset(self):
        if not self.data_files:
            raise ValueError("No data files found.")
        self.current_index = random.randint(0, len(self.data_files) - 1)
        self.current_data = self.load_data(self.data_files[self.current_index])
        print(f"Loaded data from: {self.data_files[self.current_index]}")
        print("Columns in current data:", self.current_data.columns.tolist())

        return self.get_state(self.current_data.sample(n=1).iloc[0])

    def step(self, action):
        # Simulate taking an action in the environment and return new state, reward
        latency = random.uniform(20, 150)  # Simulated latency value
        throughput = random.uniform(100, 600)  # Simulated throughput value
        packet_loss = random.uniform(0, 1)  # Simulated packet loss value

        reward = self.calculate_reward(latency, throughput, packet_loss)

        # Move to the next entry in the dataset (circular)
        self.current_index = (self.current_index + 1) % len(self.current_data)

        return self.get_state(self.current_data.iloc[self.current_index]), reward

    def get_state(self, data_entry):
        return np.array([
            data_entry['port_src'],
            data_entry['port_dst'],
            data_entry['x_packets'],
            data_entry['ip_proto']  # You may need to encode this properly
        ])

    def calculate_reward(self, latency, throughput, packet_loss):
        reward = 0
        if latency < 50:
            reward += 10
        elif latency > 100:
            reward -= 10

        if throughput > 500:  # Arbitrary threshold for good throughput
            reward += 5

        if packet_loss > 0:
            reward -= (5 * packet_loss)

        return reward


# Ant Colony Optimization Class
class ACOVPNRouting:
    def __init__(self, env, n_ants=10, n_iterations=100, alpha=1, beta=2, evaporation_rate=0.5, pheromone_init=1.0):
        self.env = env
        self.n_ants = n_ants
        self.n_iterations = n_iterations
        self.alpha = alpha  # Pheromone importance
        self.beta = beta    # Heuristic importance
        self.evaporation_rate = evaporation_rate
        self.pheromone_init = pheromone_init

        # Pheromone matrix initialization
        self.pheromone_matrix = np.full((env.action_size, env.action_size), pheromone_init)

    def fitness_function(self, solution):
        # Calculate the total reward for a sequence of actions
        total_reward = 0
        state = self.env.reset()
        for action in solution:
            new_state, reward = self.env.step(action)
            total_reward += reward
            state = new_state
        return total_reward

    def run(self):
        best_solution = None
        best_fitness = -float('inf')

        fitness_history = []

        for iteration in range(self.n_iterations):
            all_solutions = []
            all_fitness = []

            for ant in range(self.n_ants):
                solution = self.generate_solution()
                fitness = self.fitness_function(solution)

                all_solutions.append(solution)
                all_fitness.append(fitness)

                # Update best solution
                if fitness > best_fitness:
                    best_fitness = fitness
                    best_solution = solution

            # Update pheromone levels
            self.update_pheromone(all_solutions, all_fitness)

            fitness_history.append(best_fitness)
            print(f"Iteration {iteration + 1}, Best Fitness: {best_fitness}")

        self.plot_fitness(fitness_history)
        print(f"Best Solution Found: {best_solution} with Fitness: {best_fitness}")

    def generate_solution(self):
        solution = []
        for i in range(100):  # Length of the solution (sequence of actions)
            action_probabilities = self.calculate_action_probabilities()
            action = np.random.choice(range(self.env.action_size), p=action_probabilities)
            solution.append(action)
        return solution

    def calculate_action_probabilities(self):
        # Calculate the probability of selecting an action based on pheromone levels and heuristics
        pheromones = self.pheromone_matrix.sum(axis=0)
        heuristics = 1 / (pheromones + 1e-10)  # Prevent division by zero

        probabilities = (pheromones ** self.alpha) * (heuristics ** self.beta)
        return probabilities / probabilities.sum()

    def update_pheromone(self, solutions, fitness_values):
        # Evaporate some pheromone
        self.pheromone_matrix *= (1 - self.evaporation_rate)

        # Deposit new pheromone based on fitness
        for solution, fitness in zip(solutions, fitness_values):
            for action in solution:
                self.pheromone_matrix[action, action] += fitness

    def plot_fitness(self, fitness_history):
        plt.plot(fitness_history)
        plt.title('Fitness over Iterations (ACO)')
        plt.xlabel('Iterations')
        plt.ylabel('Fitness')
        plt.show()


# Usage Example
data_folder_path = r"D:\Final Capstone\Output"  # Replace with your dataset folder path
env = VPNRoutingEnv(data_folder_path)
aco = ACOVPNRouting(env)
aco.run()
